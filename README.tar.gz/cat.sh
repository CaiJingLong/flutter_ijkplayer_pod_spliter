 wget https://cdn.jsdelivr.net/gh/CaiJingLong/flutter_ijkplayer_pod_spliter@0.2.3/IJKMediaFramework.tar.xz.aa
 wget https://cdn.jsdelivr.net/gh/CaiJingLong/flutter_ijkplayer_pod_spliter@0.2.3/IJKMediaFramework.tar.xz.ab
 wget https://cdn.jsdelivr.net/gh/CaiJingLong/flutter_ijkplayer_pod_spliter@0.2.3/IJKMediaFramework.tar.xz.ac
 wget https://cdn.jsdelivr.net/gh/CaiJingLong/flutter_ijkplayer_pod_spliter@0.2.3/IJKMediaFramework.tar.xz.ad
 cat IJKMediaFramework.tar.xz.* > IJKMediaFramework.tar.xz
 tar xvf IJKMediaFramework.tar.xz
 rm IJKMediaFramework.tar.xz.* IJKMediaFramework.tar.xz

