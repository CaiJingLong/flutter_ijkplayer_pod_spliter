# FlutterIJK

For flutter_ijkplayer of iOS.
